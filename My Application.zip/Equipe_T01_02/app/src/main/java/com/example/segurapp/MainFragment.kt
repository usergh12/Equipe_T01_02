package com.example.segurapp

import android.os.Bundle
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.segurapp.databinding.FragmentMainBinding
import com.google.firebase.auth.FirebaseAuth

class MainFragment : Fragment() {

    private var _binding: FragmentMainBinding? = null
    private val binding get() = _binding!!
    private lateinit var auth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentMainBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth = FirebaseAuth.getInstance()


        setupButtonClickListeners()
    }

    private fun setupButtonClickListeners() {
        binding.btnLogin.setOnClickListener {
            val email = binding.editTextEmail.text.toString().trim()
            val password = binding.editTextPassword.text.toString().trim()
            loginUser(email, password)
        }

        binding.txtCadastro.setOnClickListener {
            findNavController().navigate(R.id.action_mainFragment_to_telaCadastro)
        }

        binding.textViewEsqueceu.setOnClickListener {
            val email = binding.editTextEmail.text.toString().trim()
            if (email.isBlank()) {
                Toast.makeText(context,"Preencha o e-mail", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(context, "Formato de e-mail inválido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            auth.sendPasswordResetEmail(email)
                .addOnCompleteListener(requireActivity()) { task ->

                    if (task.isSuccessful) {
                        Toast.makeText(context, "E-mail de redefinição de senha enviado com sucesso", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "O envio falhou!", Toast.LENGTH_LONG).show()

                    }
                }
        }
    }

    private fun loginUser(email: String, password: String) {
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(context, "Preencha e-mail e senha", Toast.LENGTH_SHORT).show()
            return
        }



        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(requireContext(), "Login Realizado com Sucesso!", Toast.LENGTH_SHORT).show()
                    val bundle = Bundle().apply {
                        putString("userEmail", email)
                    }
                    findNavController().navigate(R.id.action_mainFragment_to_telaRegistro, bundle)

                } else {
                    Toast.makeText(requireContext(), "Erro inesperado: ${task.exception?.message}", Toast.LENGTH_LONG).show()

                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}