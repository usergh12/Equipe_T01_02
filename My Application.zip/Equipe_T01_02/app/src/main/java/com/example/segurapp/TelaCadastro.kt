package com.example.segurapp

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.segurapp.databinding.FragmentRegisterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.auth.FirebaseUser
import android.util.Patterns

class TelaCadastro : Fragment(R.layout.fragment_register) {

    private lateinit var autenticacao: FirebaseAuth
    private var _binding: FragmentRegisterBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentRegisterBinding.bind(view)
        autenticacao = FirebaseAuth.getInstance()

        configurarListenerBotaoCadastro()
        configurarListenerLinkVoltar()
    }

    private fun configurarListenerBotaoCadastro() {
        binding.btnCadastro.setOnClickListener {
            binding.btnCadastro.isEnabled = false
            val nome = binding.edtNome.text.toString().trim()
            val setor = binding.edtCargo.text.toString().trim()
            val email = binding.edtEmail.text.toString().trim()
            val senha = binding.edtSenha.text.toString()

            registrarUsuario(nome, setor, email, senha)
        }
    }

    private fun configurarListenerLinkVoltar() {
        binding.txtVoltarLogin.setOnClickListener {
            findNavController().navigate(R.id.action_telaCadastro_to_login)
        }
    }

    private fun registrarUsuario(nome: String, setor: String, email: String, senha: String) {
        if (email.isEmpty() || senha.isEmpty() || nome.isEmpty() || setor.isEmpty()) {
            Toast.makeText(context, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            return
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(context, "Formato de e-mail inválido", Toast.LENGTH_SHORT).show()
            return
        }
        if (senha.length < 6) {
            Toast.makeText(context, "A senha deve ter no mínimo 6 caracteres", Toast.LENGTH_SHORT).show()
            return
        }

        autenticacao.createUserWithEmailAndPassword(email, senha)
            .addOnCompleteListener { tarefaCriacao ->
                if (tarefaCriacao.isSuccessful) {
                    val usuario = autenticacao.currentUser
                    val atualizacoesPerfil = UserProfileChangeRequest.Builder()
                        .setDisplayName(nome)
                        .build()

                    usuario?.updateProfile(atualizacoesPerfil)
                        ?.addOnCompleteListener { tarefaPerfil ->
                            if (tarefaPerfil.isSuccessful) {
                                usuario?.let {
                                    saveUserDataToFirestore(it, nome, setor, email)
                                }
                            }
                        } ?: run {
                        findNavController().navigate(R.id.action_telaCadastro_to_login)
                    }
                } else {
                    Toast.makeText(context, "Falha ao registrar: ${tarefaCriacao.exception?.message}", Toast.LENGTH_LONG).show()
                }
            }
        binding.btnCadastro.isEnabled = true

    }

    private fun saveUserDataToFirestore(user: FirebaseUser, nome: String, setor: String, email: String) {
        val db = FirebaseFirestore.getInstance()

        val userData = mapOf(
            "nome" to nome,
            "email" to email,
            "setor" to setor
        )

        db.collection("Usuarios")
            .document(user.uid)
            .set(userData)
            .addOnSuccessListener {
                Toast.makeText(context, "Usuário registrado com sucesso", Toast.LENGTH_SHORT).show()
                findNavController().navigate(R.id.action_telaCadastro_to_login)
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "Erro ao salvar dados no Firestore", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
